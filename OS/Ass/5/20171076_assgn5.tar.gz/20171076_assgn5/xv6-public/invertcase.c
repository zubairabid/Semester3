#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  int i, j, oldvar, newvar;

  for(i = 1; i < argc; i++){
    for (j = 0; argv[i][j] != 0; j++) {

      oldvar = (int)argv[i][j];
      // printf(1, "%d\t", oldvar);
      if (oldvar >= 65 && oldvar <= 90) {
        newvar = oldvar + 32;
      }
      else if (oldvar >= 97 && oldvar <= 122) {
        newvar = oldvar - 32;
      }
      else {
        newvar = oldvar;
      }
      // printf(1, "%d\n", newvar);
      printf(1, "%c", (char)newvar);
    }
    printf(1, "%s", " ");
  }
  printf(1, "%s", "\n");
  exit();
}
