#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main() {
  int i, j, k = 0, /*l, m, n,*/ id;
  for (i = 0; i < 3; i++) {
    if ((id=fork()) < 0) {
      // Error
      printf(1, "Error garbage: %d\n", k);
    }
    else if (id == 0) {
      // Child
      printf(1, "Child created: pid = %d\n", getpid());
      // timewasting
      for (j = 0; j < 10000000; j++) {
        // for(l = 0; l < 1000000000; l++) {
        //   for(m = 0; m < 1000000000; m++) {
        //     for(n = 0; n < 1000000000; n++) {
              k = 2017*i + j%1076;
              // printf(1, "%d:%d;", getpid(), k);
              printf(1, "");
        //     }
        //   }
        // }
      }
      printf(1, "Child exiting: pid = %d\n", getpid());
    }
    else {
      // Parent
      printf(1, "Parent pid=%d creating child pid=%d\n", getpid(), id);
      wait();
      printf(1, "Parent pid=%d done\n", getpid(), id);
    }
  }
}
