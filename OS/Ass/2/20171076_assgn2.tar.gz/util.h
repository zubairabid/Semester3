char **parseline(char *line, int *argc);
char **splitlines(char *line, int *num);
