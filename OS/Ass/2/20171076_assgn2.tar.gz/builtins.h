int shcd(char **argv, int argc);
int shpwd();
int shexit();
int shecho(char **argv, int argc);
int remind(char **argv, int argc);
