typedef struct {
  char name[2048];
  int pid;
  int fore;
} process;

int backCount = 0;
process currentProcess;
process bgProcess[2048];
