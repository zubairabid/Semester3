int exe(char **argv, int argc);
int run(char **argv, int argc);
int startProc(char **argv, int argc);
int prex(char **argv);
