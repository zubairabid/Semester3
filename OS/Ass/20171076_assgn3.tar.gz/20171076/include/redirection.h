int redirect(char **argv, int argc);
