int pinfo(char **argv, int argc);
