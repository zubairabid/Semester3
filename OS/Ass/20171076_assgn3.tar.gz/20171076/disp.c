#include <stdio.h>
#include <sys/utsname.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>
#include <stdlib.h>
#include <signal.h>

#include "disp.h"

typedef struct {
  char name[2048];
  int pid;
  int fore;
} process;

extern int backCount;
extern process currentProcess;
extern process bgProcess[2048];

int prompt() {
	struct utsname buf;
	char *user = (char*)malloc(HOST_NAME_MAX * sizeof(char*));
	char *cdir = (char*)malloc(PATH_MAX * sizeof(char*));

	// Getting system details
	uname(&buf);
	// hostname, path (might want error checking on this lad)
	user = getenv("USER");
	getcwd(cdir, PATH_MAX);
	process arr[2048];
	int count = 0, errno;
	for(int i = 0; i < backCount; i++) {
		int store = kill(bgProcess[i].pid, 0);
		if(store == -1) {
			printf("%s with Process ID %d Exited Normally.\n", bgProcess[i].name, bgProcess[i].pid);
			continue;
		}
		if(bgProcess[i].fore == 0) {
			arr[count] = bgProcess[i];
			++count;
		}
	}
	backCount = count;
	for(int i = 0; i <= backCount; ++i) {
		bgProcess[i] = arr[i];
	}


	printf("\n<%s@%s:%s> ", user, buf.nodename, cdir);

	return 1;
}
